import java.io.*;
import java.net.*;
import java.util.*;

public class ClientHandler implements Runnable{

    private Socket client;
    private BufferedReader in;
    private PrintWriter out;
    private ArrayList<ClientHandler> clients;
    private String username;
    

    public ClientHandler(Socket s,ArrayList<ClientHandler> clients) throws IOException {
        this.client= s;
        this.clients=clients;
        in= new BufferedReader (new InputStreamReader(client.getInputStream())); 
        out=new PrintWriter(client.getOutputStream(),true); 
    }
    
    

    @Override
    public void run() {
      try {
            String clientMessage;
            while ((clientMessage = in.readLine()) != null) {
                System.out.println("Received from client: " + clientMessage);
                broadcast(clientMessage);  // Broadcasting the message to all connected clients
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                client.close();  // Close the socket on disconnect
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void broadcast(String message) {
        for (ClientHandler client : clients) {
            client.out.println(message);  // Send the message to every client
        }
    }
    
    public String getUsername() {
        return username; // Return the client's username
    }
    
    private void broadcastUsernames() {
    StringBuilder usernamesList = new StringBuilder("Connected users: ");
    for (ClientHandler client : clients) {
        usernamesList.append(client.getUsername()).append(", ");
    }
    // Send the list of usernames to all clients
    broadcast(usernamesList.toString());
}
    
    
}