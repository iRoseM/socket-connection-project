import java.io.*;
import java.net.*; 
import java.util.*;

public class Server {
    
    private static ArrayList<ClientHandler> clients=new ArrayList<>();
    private static ArrayList<String> clientNames = new ArrayList<>();
    private static PrintWriter out;
    private static BufferedReader in;
    private Socket server;
    static Client clientframe;
    static int port = start.Server_port;

      
    public Server() throws IOException {
        ServerSocket serverSocket = new ServerSocket(port);
        System.out.println("Server is running on port " + port);
        
        while (true) {
            Socket socket = serverSocket.accept();
            clientframe = new Client(); // Adjust as necessary, or pass socket to a new Client instance
            
            new Thread(() -> {
                try {
                    String clientMessage;
                    while ((clientMessage = in.readLine()) != null) {
                        System.out.println("Received from client: " + clientMessage);
                        if (clientMessage.startsWith("Name:")) {
                            String playerName = clientMessage.substring(5);  // Extract the player name
                            clientNames.add(playerName);
                            System.out.println("Player name is: " + playerName);
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();
        }
    }
         
    public static void startServer() throws IOException {
        ServerSocket serverSocket = null;
        try{
        serverSocket = new ServerSocket(port);
        System.out.println("Server is running and listening on port"+ port);
        
        while (true) {
            
            System.out.println("Waiting for client connection...");
            Socket client = serverSocket.accept();
            
            clientframe= new Client();
            clientframe.updateConnectedPlayers("" +getConnectedUsernames());
            System.out.println("Client connected");

            // Create a new thread for each client that connects
            ClientHandler clientHandler = new ClientHandler(client, clients);
            clients.add(clientHandler);
            new Thread(clientHandler).start();
        }} catch (IOException e) {
            e.printStackTrace();
        } finally {
            // This block ensures that the server socket is closed, releasing the port
            if (serverSocket != null && !serverSocket.isClosed()) {
                try {
                    serverSocket.close();
                    System.out.println("Server socket closed.");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
}
    }
        
    
    
     public static synchronized String broadcastConnectedPlayers() {
        StringBuilder connectedPlayers = new StringBuilder();
        for (ClientHandler client : clients) {
            String username= start.playername;
            connectedPlayers.append(username).append(",");
        }

        if (connectedPlayers.length() > 0) {
            connectedPlayers.setLength(connectedPlayers.length() - 1);
        }

        String playerList = "CONNECTED_PLAYERS:" + connectedPlayers.toString();
//        out.println(playerList);  // Send the list to the specific client
        return playerList;
     }
//     private synchronized void addClient(ClientHandler client) {
//        clients.add(client); // Add the new client to the list
//        out.println(broadcastConnectedPlayers()); // Print connected players
//    }
   
    // Method to get all usernames
    public static synchronized List<String> getConnectedUsernames() {
        List<String> usernames = new ArrayList<>();
        for (ClientHandler client : clients) {
            usernames.add(client.getUsername());
        }
        return usernames;
    }
    
     
    public static void main(String argv[]) throws Exception {
            startServer();
        } 
 
}

